Python 3.8.4 (tags/v3.8.4:dfa645a, Jul 13 2020, 16:30:28) [MSC v.1926 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> data = "Hi there!"
>>> for index in range(len(data)):
	print(index, data[index])

	
0 H
1 i
2  
3 t
4 h
5 e
6 r
7 e
8 !
>>> 