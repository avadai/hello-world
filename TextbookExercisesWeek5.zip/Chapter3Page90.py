import random
for roll in range(10):
    print(random.randint(1, 6), end = " ")