theSum = 0
count = 1
while count <= 100000:
    theSum += count
    count += 1
print(theSum)