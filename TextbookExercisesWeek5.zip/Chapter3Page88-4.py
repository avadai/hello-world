count = 10
while count >= 1:
    print(count, end=" ")
    count -= 1