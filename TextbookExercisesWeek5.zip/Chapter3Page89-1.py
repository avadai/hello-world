theSum = 0.0
while True:
    data = input("Enter a number or press 'Enter' to quit: ")
    if data == "":
        break
    number = float(data)
    theSum += number
print("The sum is", theSum)