Python 3.8.4 (tags/v3.8.4:dfa645a, Jul 13 2020, 16:30:28) [MSC v.1926 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> A = True
>>> B = False
>>> A and B
False
>>> A or B
True
>>> not A
False
>>> A = 4
>>> B = 5
>>> result = A + B * 2 < 10 or B == 6
>>> result
False
>>> #The code in the example was returning "True" on my end.