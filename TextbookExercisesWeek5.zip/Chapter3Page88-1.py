theSum = 0
for count in range(1, 100001):
    theSum += count
print(theSum)
